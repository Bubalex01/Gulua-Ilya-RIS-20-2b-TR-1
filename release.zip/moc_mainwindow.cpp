/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Calc/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[25];
    char stringdata0[354];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 23), // "on_box_period_activated"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 5), // "index"
QT_MOC_LITERAL(4, 42, 23), // "on_box_valyta_activated"
QT_MOC_LITERAL(5, 66, 28), // "on_line_srok_editingFinished"
QT_MOC_LITERAL(6, 95, 27), // "on_line_sum_editingFinished"
QT_MOC_LITERAL(7, 123, 28), // "on_line_fees_editingFinished"
QT_MOC_LITERAL(8, 152, 30), // "on_line_stavka_editingFinished"
QT_MOC_LITERAL(9, 183, 11), // "Calculation"
QT_MOC_LITERAL(10, 195, 10), // "EveryMonth"
QT_MOC_LITERAL(11, 206, 3), // "sum"
QT_MOC_LITERAL(12, 210, 6), // "stavka"
QT_MOC_LITERAL(13, 217, 4), // "fees"
QT_MOC_LITERAL(14, 222, 8), // "sroktype"
QT_MOC_LITERAL(15, 231, 3), // "val"
QT_MOC_LITERAL(16, 235, 4), // "srok"
QT_MOC_LITERAL(17, 240, 6), // "QDate&"
QT_MOC_LITERAL(18, 247, 4), // "date"
QT_MOC_LITERAL(19, 252, 12), // "EveryQuarter"
QT_MOC_LITERAL(20, 265, 9), // "EveryYear"
QT_MOC_LITERAL(21, 275, 10), // "RemoveRows"
QT_MOC_LITERAL(22, 286, 11), // "CheckErrors"
QT_MOC_LITERAL(23, 298, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(24, 322, 31) // "on_box_srok_currentIndexChanged"

    },
    "MainWindow\0on_box_period_activated\0\0"
    "index\0on_box_valyta_activated\0"
    "on_line_srok_editingFinished\0"
    "on_line_sum_editingFinished\0"
    "on_line_fees_editingFinished\0"
    "on_line_stavka_editingFinished\0"
    "Calculation\0EveryMonth\0sum\0stavka\0"
    "fees\0sroktype\0val\0srok\0QDate&\0date\0"
    "EveryQuarter\0EveryYear\0RemoveRows\0"
    "CheckErrors\0on_pushButton_2_clicked\0"
    "on_box_srok_currentIndexChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   84,    2, 0x08 /* Private */,
       4,    1,   87,    2, 0x08 /* Private */,
       5,    0,   90,    2, 0x08 /* Private */,
       6,    0,   91,    2, 0x08 /* Private */,
       7,    0,   92,    2, 0x08 /* Private */,
       8,    0,   93,    2, 0x08 /* Private */,
       9,    0,   94,    2, 0x08 /* Private */,
      10,    7,   95,    2, 0x08 /* Private */,
      19,    7,  110,    2, 0x08 /* Private */,
      20,    7,  125,    2, 0x08 /* Private */,
      21,    0,  140,    2, 0x08 /* Private */,
      22,    0,  141,    2, 0x08 /* Private */,
      23,    0,  142,    2, 0x08 /* Private */,
      24,    0,  143,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Int, QMetaType::Int, QMetaType::Int, 0x80000000 | 17,   11,   12,   13,   14,   15,   16,   18,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Int, QMetaType::Int, QMetaType::Int, 0x80000000 | 17,   11,   12,   13,   14,   15,   16,   18,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Int, QMetaType::Int, QMetaType::Int, 0x80000000 | 17,   11,   12,   13,   14,   15,   16,   18,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_box_period_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->on_box_valyta_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_line_srok_editingFinished(); break;
        case 3: _t->on_line_sum_editingFinished(); break;
        case 4: _t->on_line_fees_editingFinished(); break;
        case 5: _t->on_line_stavka_editingFinished(); break;
        case 6: _t->Calculation(); break;
        case 7: _t->EveryMonth((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< QDate(*)>(_a[7]))); break;
        case 8: _t->EveryQuarter((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< QDate(*)>(_a[7]))); break;
        case 9: _t->EveryYear((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< QDate(*)>(_a[7]))); break;
        case 10: _t->RemoveRows(); break;
        case 11: { bool _r = _t->CheckErrors();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 12: _t->on_pushButton_2_clicked(); break;
        case 13: _t->on_box_srok_currentIndexChanged(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
